package cOLLECTION;

import java.util.LinkedList;

public class LinkedlistEmp10 
{
	
	
	 public static void main(String args[])
	 {
		LinkedList<String> a1=new LinkedList<String>();
		 a1.add("Swarupa");
		 a1.add("Ashish");
		 a1.add("Nachiket");
		 a1.add("Nikil");
		 a1.add("Prathamsh");
		 
		 for(int i=0;i<=4;i++)
		 {
			 System.out.println(a1.get(i));
		 }
	 }

	}


