package dao;
import java.sql.*;
import model.*;
public class LoginDao 
{
	Connection conn;
	public LoginDao()throws Exception
	{
		Class.forName("org.h2.Driver");
		conn=DriverManager.getConnection("jdbc:h2:tcp://localhost/~/test", "sa", "");
	}
	
	public boolean isValid(Login loginobj)throws Exception
	{
		PreparedStatement psmt=conn.prepareStatement("select * from LOGIN1 where name=? and password=?");
		
		psmt.setString(1,loginobj.getLogin().trim());
		psmt.setString(2, loginobj.getPassword().trim());
		
		ResultSet rs=psmt.executeQuery();
		
		if(rs.next())
			return true;
		else
			return false;
	}
}
