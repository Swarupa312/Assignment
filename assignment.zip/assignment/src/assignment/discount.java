package assignment;

import java.util.Scanner;

//>=5000 and <6000 - 12.5% ,>=6000 and <10000 - 14.2% and >=10000 will be 16% and less than 5000 there should not be any disocunt
public class discount 
{
	int pv;
	double d;
 	public void accept()
 	{
 		Scanner sr=new Scanner(System.in);
 		System.out.println("enetr purchase value");
 		pv=sr.nextInt();
 	}
 	public void display()
 	{
 		if (pv>10000)
 		{
 			d=pv-16.1/100*pv;;
 			System.out.println( "so final price is :"+ d);
 		}
 		
 		else if(pv>=5000 && pv<=6000)
 		{
 			d=pv-12.5/100*pv;
 			
 			System.out.println( "so final price is :"+d);
 		}
 		else if(pv>6000 && pv<=10000)
 		{
 			d=pv-14.2/100*pv;
 			
 			System.out.println( "so final price is :"+d);
 		}
 		else
 		{
 			System.out.println( "No discount");
 			System.out.println( "so final price is :"+pv);
 		}
 	}
}

class discountmain
{
	public static void main(String args[])
	{
		discount l=new discount();
		l.accept();
		l.display();
		
	}

}
